# 🐾 Pixel Pet — Desktop Companion

A tiny pixel-art cat that lives on your desktop.

## Quick Start
1. Open Terminal in this directory.
2. Run: `npm install`
3. Run: `npm start`

Enjoy your pixel pet desktop cat! 🐾
